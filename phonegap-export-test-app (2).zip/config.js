define( function ( require ) {

	"use strict";

	return {
		app_slug : 'test-app',
		wp_ws_url : 'http://192.168.100.105/woo/wp-appkit-api/test-app',
		wp_url : 'http://192.168.100.105/woo',
		theme : 'q-android-1.0.4',
		version : '1.0',
		app_title : 'App Title',
		app_platform : 'android',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '!:J,.FpqVjI7^}H^:`RmBTiN~+cgH1I-6efMa+}6A}N)_ n00<EYy3GSK *@GCAz',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
