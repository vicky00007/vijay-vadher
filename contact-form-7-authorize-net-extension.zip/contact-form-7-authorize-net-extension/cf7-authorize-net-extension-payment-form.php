<?php
/* @access      public
 * @since       1.0 
 * @return      $content
*/
if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}

/*===================== Contact Form 7 - authorize Extension ====================*/
/*================== authorize Payment Form - Frontend Section ==================*/
/**
** A base module for authorize express checkout form that allows to submit payment from Contact Form 7.
**/
session_start();
add_filter('wp_head', 'wpcf7_add_authorize_script', 10, 2);
function wpcf7_add_authorize_script(){	
?>
<script type="text/javascript">   
	jQuery(document).ready(function() {
	    jQuery('.wpcf7').each(function(index, element){		
			var data = {
				'action': 'enable_authorize_gateway',
				'form': jQuery(this).find('input[name=_wpcf7]').val()
			};
			var elements = jQuery(this);
			var $form = jQuery(this).find('form');
			jQuery.post("<?php echo admin_url('admin-ajax.php'); ?>", data, function(response) {							
				$form.append(jQuery('<input type="hidden" name="enable_authorize"/>').val(response.trim()));	
			});
		
			jQuery(document).on('mailsent.wpcf7', function (e) {
				var enable_authorize = elements.find('input[name=enable_authorize]').val();
				if(enable_authorize == '1')
				{
					var data = {
						'action': 'authorize_payment_gateway',
						'form': $form.serializeArray()
					};
					jQuery.post("<?php echo admin_url('admin-ajax.php'); ?>", data, function(data) {
						jQuery(elements).html(data);
					});
				}			
			});	
		});		
	});	 
</script> 
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<?php }

function wpcf7_authorize_enable_payment_gateway() {
	$form_id = $_POST['form'];
	$enable = get_post_meta( $form_id, "_cf7authorize_use", true);
	echo $enable;
	wp_die();
}
add_action( 'wp_ajax_enable_authorize_gateway', 'wpcf7_authorize_enable_payment_gateway' );
add_action( 'wp_ajax_nopriv_enable_authorize_gateway', 'wpcf7_authorize_enable_payment_gateway' );


function wpcf7_authorize_payment_gateway_form() {
	$form = $_POST['form'];
	foreach($form as $data){
		$formdata[$data['name']] = $data['value'];
	}
	if(isset($_POST['form']))
	{		
		$form_id = $formdata['_wpcf7'];
		$apimode = get_post_meta( $form_id, "_cf7authorize_mode", true);

		$buttonlabel = get_post_meta( $form_id, "_cf7authorize_buttonlabel", true);
		$amount_field = get_post_meta( $form_id, "_cf7authorize_amount", true);
		$description_field = get_post_meta( $form_id, "_cf7authorize_description", true);
		$quantity_field = get_post_meta( $form_id, "_cf7authorize_quantity", true);
		$currency = get_post_meta( $form_id, "_cf7authorize_currency", true);
		$returnURL = get_post_meta( $form_id, "_cf7authorize_returnurl", true);

		if(isset($amount_field) && !empty($amount_field)){
			$amount = $formdata[$amount_field];
		}		
		if(isset($description_field) && !empty($description_field)){
			$description = $formdata[$description_field];
		}		
		if(isset($quantity_field) && !empty($quantity_field)){
			$quantity = $formdata[$quantity_field];
		}		
		if($amount == "")
		{
			echo '<span class="warning">Warning : You have not configured Amount field properly.</span><br><br>';
		} 
		if($description == "" && !empty($description_field)){
			echo '<span class="warning">Warning : You have not configured Description field properly.</span><br><br>';
		}		
		if($quantity == "" && !empty($quantity_field)){
			echo '<span class="warning">Warning : You have not configured Quantity field properly.</span><br><br>';
		}		
?>
	  	<script type="text/javascript">
		  var returnurl = '<?php echo $returnURL;?>';
		  function chkpay(id) {
		  	jQuery(".authorize-loading").css('display','block');
		  	var $form = jQuery('.authorize-form #'+id);
				var data = {
					'action': 'authorize_payment_charge',
					'dataType' : 'json',
					'form': $form.serializeArray()					
				};
				jQuery.post("<?php echo admin_url('admin-ajax.php'); ?>", data, function(response) {
					var data = response.split("|");
					jQuery('.authorize-response-error').hide();
					jQuery('.authorize-response-success').hide();
					if(data[0].trim() == 'false')
					{
						jQuery(".authorize-loading").css('display','none');		
						jQuery('.authorize-response-error').show();
						jQuery('.authorize-response-error').text(data[1]);
						$form.find('button').prop('disabled', false);
					}
					else
					{		
						jQuery('.authorize-response-success').show();
						jQuery('.authorize-response-success').text(data[1]);
						if(returnurl != ""){
							jQuery("#authorize_button").html('Redirecting....');											
							setTimeout(function(){
						     window.location = returnurl;
						   },2000); 
						}	else {
							jQuery(".authorize-loading").css('display','none');	
							jQuery('#authorize-payment-form-debit').find('button').prop('disabled', true);
							jQuery('#authorize-payment-form-credit').find('button').prop('disabled', true);
						}											
					}
				});		        
		      
		    };    
		</script> 
		<div class="authorize-form">
		<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#credit">Credit Card</a></li>
			  <li><a data-toggle="tab" href="#debit">Debit Card</a></li>
			</ul>
			<div class="tab-content">
			  <div id="credit" class="tab-pane fade in active">
			    <form id="authorize-payment-form-credit" action="#" method="POST">	
			    	<h4>Your Credit Card Detail :</h4>		
					<p>Card holder name
						<span class="authorize-cardholdername"><input type="text" placeholder="Name" name="cardholdername" size="20" value="test"></span>
					</p>
					<p>Card Number (required)
						<span class="authorize-cardnumber"><input type="text" placeholder="4242424242424242" value="6011000000000012" name="card_number" data-authorize="number" size="20"></span>
					</p>
					<p>Card Expiry Date (required)
						<span class="authorize-expires">
							<input type="text" placeholder="10" value="10" name="exp_month" data-authorize="exp-month" size="2" id="authorize-month">
							/ <input type="text" placeholder="2017" value="2019" name="exp_year" data-authorize="exp-year" size="4" id="authorize-year">
						</span>
					</p>
					<p>Card CVV (required)
						<span class="authorize-cvv">
							<input type="text" placeholder="123" value="900" name="cvv_number" data-authorize="cvc" size="4">
						</span>
					</p>				
					<input type="hidden" name="form_id" value="<?php echo $form_id;?>">
					<?php if(isset($amount) && !empty($amount)){ ?>
						<input type="hidden" name="amount" value="<?php echo $amount;?>">
					<?php } ?>
					<?php if(isset($description) && !empty($description)){ ?>
						<input type="hidden" name="description" value="<?php echo $description;?>">
					<?php } ?>
					<?php if(isset($quantity) && !empty($quantity)){ ?>
						<input type="hidden" name="quantity" value="<?php echo $quantity;?>">
					<?php } ?>
					<?php if(isset($currency) && !empty($currency)){ ?>
						<input type="hidden" name="currency" value="<?php echo $currency;?>">
					<?php } ?>	
					<button type="button" id="authorize_button" onclick="chkpay('authorize-payment-form-credit');"><?php echo (empty($buttonlabel)) ? 'Submit' : $buttonlabel;?></button>
					<span class="authorize-loading"></span>
				</form>
			  </div>
			  <div id="debit" class="tab-pane fade">
			    <h4>Your Debit Card Detail :</h4>
			    <form id="authorize-payment-form-debit" action="#" method="POST">			
					<p>Card holder name
						<span class="authorize-cardholdername"><input type="text" placeholder="Name" name="cardholdername" size="20"></span>
					</p>
					<p>Card Number (required)
						<span class="authorize-cardnumber"><input type="text" placeholder="4242424242424242" name="card_number" data-authorize="number" size="20"></span>
					</p>
					<p>Card Expiry Date (required)
						<span class="authorize-expires">
							<input type="text" placeholder="10" name="exp_month" data-authorize="exp-month" size="2" id="authorize-month">
							/ <input type="text" placeholder="2017" name="exp_year" data-authorize="exp-year" size="4" id="authorize-year">
						</span>
					</p>
					<p>Card CVV (required)
						<span class="authorize-cvv">
							<input type="text" placeholder="123" name="cvv_number" data-authorize="cvc" size="4">
						</span>
					</p>				
					<input type="hidden" name="form_id" value="<?php echo $form_id;?>">
					<?php if(isset($amount) && !empty($amount)){ ?>
						<input type="hidden" name="amount" value="<?php echo $amount;?>">
					<?php } ?>
					<?php if(isset($description) && !empty($description)){ ?>
						<input type="hidden" name="description" value="<?php echo $description;?>">
					<?php } ?>
					<?php if(isset($quantity) && !empty($quantity)){ ?>
						<input type="hidden" name="quantity" value="<?php echo $quantity;?>">
					<?php } ?>
					<?php if(isset($currency) && !empty($currency)){ ?>
						<input type="hidden" name="currency" value="<?php echo $currency;?>">
					<?php } ?>	
					<button type="button" id="authorize_button" onclick="chkpay('authorize-payment-form-debit');"><?php echo (empty($buttonlabel)) ? 'Submit' : $buttonlabel;?></button>
					<span class="authorize-loading"></span>
				</form>
			  </div>
			</div>
			
		</div>
		<div class="authorize-response-error"></div><div class="authorize-response-success"></div>
<?php
		wp_die(); 			
	}
}
add_action( 'wp_ajax_authorize_payment_gateway', 'wpcf7_authorize_payment_gateway_form' );
add_action( 'wp_ajax_nopriv_authorize_payment_gateway', 'wpcf7_authorize_payment_gateway_form' );

function wpcf7_get_authorize_payment_details()
{
	$form = $_POST['form'];
	foreach($form as $data){
		$formdata[$data['name']] = $data['value'];
	}
	
	$form_id = $formdata['form_id'];
	$amount = (isset($formdata['amount']) && !empty($formdata['amount']) && is_numeric($formdata['amount'])) ? $formdata['amount'] : 0;
	$description = (isset($formdata['description']) && !empty($formdata['description'])) ? $formdata['description'] : '';
	$quantity = (isset($formdata['quantity']) && !empty($formdata['quantity'])) ? $formdata['quantity'] : 1;
	$currency = (isset($formdata['currency']) && !empty($formdata['currency'])) ? $formdata['currency'] : 'USD';
	$amount = $amount * 100 * $quantity;

	$apimode = get_post_meta( $form_id, "_cf7authorize_mode", true);
	if ($apimode == '1') {
        define("AUTHORIZENET_SANDBOX", true);
    } else {
        define("AUTHORIZENET_SANDBOX", false);
    }
    $apikey = get_post_meta( $form_id, "_cf7authorize_liveapikey", true);

    $livepublishkey = get_post_meta( $form_id, "_cf7authorize_livepublishkey", true);
    $methodToUse = get_post_meta( $form_id, "_cf7authorize_auth_method", true);
	define("AUTHORIZENET_TRANSACTION_KEY", $livepublishkey);
	define("AUTHORIZENET_API_LOGIN_ID", $apikey);
	$REQUEST = array();

	$REQUEST['first_name'] = mysql_real_escape_string($formdata['cardholdername']);
	$REQUEST['x_card_num'] = mysql_real_escape_string($formdata['card_number']);
	$REQUEST['card_type'] = mysql_real_escape_string(cardType($formdata['card_number']));
    $REQUEST['exp_month'] = mysql_real_escape_string($formdata['exp_month']);
    $REQUEST['exp_year'] = mysql_real_escape_string($formdata['exp_year']);
    $REQUEST['x_card_code'] = mysql_real_escape_string($formdata['cvv_number']);
	$REQUEST['amount'] = mysql_real_escape_string($amount);
	$REQUEST['payment_method'] = mysql_real_escape_string($methodToUse);
	$REQUEST['comment'] = mysql_real_escape_string($description);
	$REQUEST['md5_hash'] = mysql_real_escape_string(md5('testingchaman13'));
	
	global $wpdb;
	$tablename = $wpdb->prefix.'cf7authorize_extension';
	$result = $wpdb->get_row("SELECT * FROM $tablename WHERE token LIKE '".$_SESSION['authorize_token']."'");
				
 		include dirname(__FILE__) . '/AuthorizeNet.php';
		// You only need to adjust the two variables below if testing DPM
        define("AUTHORIZENET_MD5_SETTING", "");
        // make a call to payment process
        $paymentStatus = "Pending";
        $payment_response = cf7apAuthorizePayment($methodToUse, $REQUEST);
        if($payment_response->approved)
        {
	        $payment_details_json = json_encode($payment_response);
	        $wpdb->update( $tablename, array( 'payment_details' => $payment_details_json), 
				array( 'id' => $result->id ), array( '%s' ), array( '%d' ) 
			);
			$success_message = get_post_meta( $form_id, "_cf7authorize_message", true);
			//exit;
			if(!isset($success_message) || empty($success_message) || $success_message=='')
			{
				$success_message = $payment_response->response_reason_text;
				//$success_message = 'Your payment has been made successfully.';
			}
			$return = 'true|'.$success_message;
			session_write_close();
			//Send Mail to User			
			auth_sendEmailToUser($form_id, $result->field_values, $payment_details_json);
			auth_sendEmailToAdmin($form_id, $result->field_values, $payment_details_json);
			echo $return;
		}
		else
		{
			$payment_details_json = json_encode($payment_response);
			$wpdb->update( $tablename, array( 'payment_details' => $payment_details_json), 
				array( 'id' => $result->id ), array( '%s' ), array( '%d' ) 
			);
			
			$error_message = $payment_response->response_reason_text;
			if(!$error_message || $error_message==''){$error_message="Please check again Card detail is not valid.";}
			$return = 'false|'.$error_message;
			echo $return;
		}
	//Send email to Admin
	wp_die();	
}

add_action( 'wp_ajax_authorize_payment_charge', 'wpcf7_get_authorize_payment_details' );
add_action( 'wp_ajax_nopriv_authorize_payment_charge', 'wpcf7_get_authorize_payment_details' );

/*Authorized validation and Payment Functions*/
function cf7apAuthorizePayment($methodToUse, $REQUEST) {
	if (!cf7apvalidateCreditCard($REQUEST['x_card_num'], $REQUEST['card_type'], $ccerror, $ccerrortext)) {
    	$res = 'false|'.$ccerrortext;
		return $res;
    } 
    else 
    {
    	if ($methodToUse == "AIM") {

            $transaction = new AuthorizeNetAIM;
            $transaction->setSandbox(AUTHORIZENET_SANDBOX);
            $transaction->setFields(
                    array(
                        'amount' => $REQUEST['amount'],
                        'card_num' => $REQUEST['x_card_num'],
                        'exp_date' => $REQUEST['exp_month'] . '/' . $REQUEST['exp_year'],
                        'first_name' => $REQUEST['first_name'],                       
                    )
            );
            $response = $transaction->authorizeAndCapture();
            if ($response->approved) {

                $res = $response;
                return $res;
            } else {
                $res = $response;
                return $res;
            }
        } 
    }
}
/**
 * function validateCreditCard
 *  
 *  Define the cards we support. You may add additional card types.
 *  Name:      As in the selection box of the form - must be same as user's
 *  Length:    List of possible valid lengths of the card number for the card
 *  Prefixes:  List of possible prefixes for the card
 *  Checkdigit Boolean to say whether there is a check digit
 *  Don't forget - all but the last array definition needs a comma separator!
 * 
 * @param type $cardnumber
 * @param type $cardname
 * @param type $errornumber
 * @param type $errortext
 * @return boolean
 * 
 * 
 */
function cf7apvalidateCreditCard($cardnumber, $cardname, &$errornumber, &$errortext) {

    $cards = array(array('name' => 'American Express',
            'length' => '15',
            'prefixes' => '34,37',
            'checkdigit' => true
        ),
        array('name' => 'Diners Club',
            'length' => '14,15',
            'prefixes' => '300,301,302,303,304,305,2014,2149',
            'checkdigit' => true
        ),
        array('name' => 'DINERS',
            'length' => '14,16',
            'prefixes' => '305,36,38,54,55',
            'checkdigit' => true
        ),
        array('name' => 'Discover',
            'length' => '16',
            'prefixes' => '6011,622,64,65',
            'checkdigit' => true
        ),
        array('name' => 'JCB',
            'length' => '16',
            'prefixes' => '35',
            'checkdigit' => true
        ),
        array('name' => 'Maestro',
            'length' => '12,13,14,15,16,18,19',
            'prefixes' => '5018,5020,5038,6304,6759,6761',
            'checkdigit' => true
        ),
        array('name' => 'MasterCard',
            'length' => '16',
            'prefixes' => '51,52,53,54,55',
            'checkdigit' => true
        ),
        array('name' => 'Solo',
            'length' => '16,18,19',
            'prefixes' => '6334,6767',
            'checkdigit' => true
        ),
        array('name' => 'Switch',
            'length' => '16,18,19',
            'prefixes' => '4903,4905,4911,4936,564182,633110,6333,6759',
            'checkdigit' => true
        ),
        array('name' => 'Visa',
            'length' => '16',
            'prefixes' => '4,417500,4917,4913,4508,4844',
            'checkdigit' => true
        ),
        array('name' => 'LaserCard',
            'length' => '16,17,18,19',
            'prefixes' => '6304,6706,6771,6709',
            'checkdigit' => true
        )
    );

    $ccErrorNo = 0;

    $ccErrors [0] = 'Please enter a valid ' . $cardname . ' number.';
    $ccErrors [1] = "No card number provided";
    $ccErrors [2] = "Credit card number has invalid format";
    $ccErrors [3] = "Credit card number is invalid";
    $ccErrors [4] = "Credit card number is wrong length";

    // Establish card type
    $cardType = -1;
    for ($i = 0; $i < sizeof($cards); $i++) {

        // See if it is this card (ignoring the case of the string)
        if (strtolower($cardname) == strtolower($cards[$i]['name'])) {
            $cardType = $i;
            break;
        }
    }

    // If card type not found, report an error
    if ($cardType == -1) {
        $errornumber = 0;
        $errortext = $ccErrors [$errornumber];
        return false;
    }

    // Ensure that the user has provided a credit card number
    if (strlen($cardnumber) == 0) {
        $errornumber = 1;
        $errortext = $ccErrors [$errornumber];
        return false;
    }

    // Remove any spaces from the credit card number
    $cardNo = str_replace(' ', '', $cardnumber);

    // Check that the number is numeric and of the right sort of length.
    if (!preg_match("/^[0-9]{13,19}$/", $cardNo)) {
        $errornumber = 2;
        $errortext = $ccErrors [$errornumber];
        return false;
    }

    // Now check the modulus 10 check digit - if required
    if ($cards[$cardType]['checkdigit']) {
        $checksum = 0;                                  // running checksum total
        $mychar = "";                                   // next char to process
        $j = 1;                                         // takes value of 1 or 2
        // Process each digit one by one starting at the right
        for ($i = strlen($cardNo) - 1; $i >= 0; $i--) {

            // Extract the next digit and multiply by 1 or 2 on alternative digits.
            $calc = $cardNo{$i} * $j;

            // If the result is in two digits add 1 to the checksum total
            if ($calc > 9) {
                $checksum = $checksum + 1;
                $calc = $calc - 10;
            }

            // Add the units element to the checksum total
            $checksum = $checksum + $calc;

            // Switch the value of j
            if ($j == 1) {
                $j = 2;
            } else {
                $j = 1;
            };
        }

        // All done - if checksum is divisible by 10, it is a valid modulus 10.
        // If not, report an error.
        if ($checksum % 10 != 0) {
            $errornumber = 3;
            $errortext = $ccErrors [$errornumber];
            return false;
        }
    }

    // The following are the card-specific checks we undertake.
    // Load an array with the valid prefixes for this card
    $prefix = explode(',', $cards[$cardType]['prefixes']);

    // Now see if any of them match what we have in the card number
    $PrefixValid = false;
    for ($i = 0; $i < sizeof($prefix); $i++) {
        $exp = '/^' . $prefix[$i] . '/';
        if (preg_match($exp, $cardNo)) {
            $PrefixValid = true;
            break;
        }
    }

    // If it isn't a valid prefix there's no point at looking at the length
    if (!$PrefixValid) {
        $errornumber = 3;
        $errortext = $ccErrors [$errornumber];
        return false;
    }

    // See if the length is valid for this card
    $LengthValid = false;
    $lengths = explode(',', $cards[$cardType]['length']);
    for ($j = 0; $j < sizeof($lengths); $j++) {
        if (strlen($cardNo) == $lengths[$j]) {
            $LengthValid = true;
            break;
        }
    }

    // See if all is OK by seeing if the length was valid.
    if (!$LengthValid) {
        $errornumber = 4;
        $errortext = $ccErrors [$errornumber];
        return false;
    };

    // The credit card is in the required format.
    return true;
}

function cardType($number)
{
    $number=preg_replace('/[^\d]/','',$number);
    if (preg_match('/^3[47][0-9]{13}$/',$number))
    {
        return 'American Express';
    }
    elseif (preg_match('/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/',$number))
    {
        return 'Diners Club';
    }
    elseif (preg_match('/^6(?:011|5[0-9][0-9])[0-9]{12}$/',$number))
    {
        return 'Discover';
    }
    elseif (preg_match('/^(?:2131|1800|35\d{3})\d{11}$/',$number))
    {
        return 'JCB';
    }
    elseif (preg_match('/^5[1-5][0-9]{14}$/',$number))
    {
        return 'MasterCard';
    }
    elseif (preg_match('/^4[0-9]{12}(?:[0-9]{3})?$/',$number))
    {
        return 'Visa';
    }
    else
    {
        return 'Unknown';
    }
}
/*END authorized validation functions */
/**
  * This function sends email to User who submits authorize payment.
  */
function auth_sendEmailToUser($form_id, $fieldvalues, $payment_details){
	$payment_details = json_decode($payment_details, true);
	$email = get_post_meta($form_id, '_mail', true);
	if(!empty($email)){
		$fields = json_decode($fieldvalues);
		$emailsubject = $email['subject'];
		$emailcontent = $email['body'];
		$recipient = $email['recipient'];
		$additional_headers = $email['additional_headers'];
		$sender = $email['sender'];
		$attachments = $email['attachments'];
		foreach($fields as $key=>$field){
			$attribute = '['.$key.']';
			if(is_array($field)){
				$field = implode(',',$field);
			}
			if(!empty($recipient)){
				$recipient = str_replace($attribute, $field, $recipient);
			}
			if(!empty($emailsubject)){
				$emailsubject = str_replace($attribute, $field, $emailsubject);
			}
			if(!empty($emailcontent)){
				$emailcontent = str_replace($attribute, $field, $emailcontent);
			}
			if(!empty($additional_headers)){
				$additional_headers = str_replace($attribute, $field, $additional_headers);
			}
			if(!empty($sender)){
				$sender = str_replace($attribute, $field, $sender);
			}
			if(!empty($attachments)){
				$attachments = str_replace($attribute, $field, $attachments);
			}				
		}	
		$authorizedetails = "<b><u>Authorize.Net Response Details:</u></b><br><br>";
		if(is_array($payment_details)) {
			foreach($payment_details as $key=>$data){					
				$authorizedetails .= ucwords($key).' - '.$data.'<br>';
			}
		} else {
			$authorizedetails .= $payment_details;
		}

		$emailcontent = str_replace('[authorize-net]', $authorizedetails, $emailcontent);
		$emailcontent = nl2br($emailcontent);			
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$headers[] = $additional_headers;
		$headers[] = 'From : '.$sender;
		if(isset($recipient) && !empty($recipient)){
			wp_mail( $recipient, $emailsubject, $emailcontent, $headers, $attachments );			
		}
	}
}

/**
  * This function sends email to Admin for any successful/unsuccessful transaction of authorize payment
  */
function auth_sendEmailToAdmin($form_id, $fieldvalues, $payment_details){
	$payment_details = json_decode($payment_details, true);
	$email = get_post_meta($form_id, '_mail_2', true);
	if(!empty($email)){
		$fields = json_decode($fieldvalues);
		$emailsubject = $email['subject'];
		$emailcontent = $email['body'];
		$recipient = $email['recipient'];
		$additional_headers = $email['additional_headers'];
		$sender = $email['sender'];
		$attachments = $email['attachments'];
		foreach($fields as $key=>$field){
			$attribute = '['.$key.']';
			if(is_array($field)){
				$field = implode(',',$field);
			}
			if(!empty($recipient)){
				$recipient = str_replace($attribute, $field, $recipient);
			}
			if(!empty($emailsubject)){
				$emailsubject = str_replace($attribute, $field, $emailsubject);
			}
			if(!empty($emailcontent)){
				$emailcontent = str_replace($attribute, $field, $emailcontent);
			}
			if(!empty($additional_headers)){
				$additional_headers = str_replace($attribute, $field, $additional_headers);
			}
			if(!empty($sender)){
				$sender = str_replace($attribute, $field, $sender);
			}
			if(!empty($attachments)){
				$attachments = str_replace($attribute, $field, $attachments);
			}				
		}	
		$authorizedetails = "<b><u>Authorize.Net Response Details:</u></b><br><br>";		
		if(is_array($payment_details)) {
			foreach($payment_details as $key=>$data){					
				$authorizedetails .= ucwords($key).' - '.$data.'<br>';
			}
		} else {
			$authorizedetails .= $payment_details;
		}
		$emailcontent = str_replace('[authorize-net]', $authorizedetails, $emailcontent);
		$emailcontent = nl2br($emailcontent);			
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$headers[] = $additional_headers;
		$headers[] = 'From : '.$sender;
		if(isset($recipient) && !empty($recipient)){
			wp_mail( $recipient, $emailsubject, $emailcontent, $headers, $attachments );
			if($attachments){
				unlink($attachments);
			}			
		}
	}
}

/**
  * This function skips mail send by Contact Form 7.
  */
add_action('wpcf7_before_send_mail', 'wpcf7_authorize_before_send_mail');
function wpcf7_authorize_before_send_mail($WPCF7_form) {
	$enable = get_post_meta( $WPCF7_form->id(), "_cf7authorize_use", true);
	if($enable == '1'){
		$WPCF7_form->skip_mail = true;
	}
}

/**
  * This function saves Contact Form 7 data to database.
  */
add_action('wpcf7_mail_sent', 'wpcf7_authorize_after_send_mail');		
function wpcf7_authorize_after_send_mail($WPCF7_form) {	
	$enable = get_post_meta( $WPCF7_form->id(), "_cf7authorize_use", true);
	if($enable == '1'){
		$WPCF7_form->additional_settings = "on_sent_ok:  \"document.getElementById('contactform').style.display = 'none';\"";		
		global $wpdb;
		$submission = WPCF7_Submission::get_instance();
	    if ($submission) {
	        $data = array();
	        $data['posted_data'] = $submission->get_posted_data();  
	        $date = current_time("Y-m-d H:i:s");
	        $form_id = $data['posted_data']['_wpcf7'];
	        
	        $uploaded_files = $submission->uploaded_files();

	        foreach($data['posted_data'] as $key=>$values){
	        	if (!preg_match('/^_(.*)$/', $key) && $key!='enable_authorize') {
	        		$fields[$key] = $values;
	        	}        	
	        }
	        foreach ( (array) $uploaded_files as $name => $path ) {
				if ( ! empty( $path ) ) {
					$newpath = WP_CONTENT_DIR .'/uploads/cf7-authorize-net-extension/';
					mkdir($newpath, 0755);
					$filename = $newpath.basename($path);
					copy($path, $filename);
					foreach($fields as $key=>$value){
						if($name == $key){
							$fields[$key] = $filename;
						}
					}
				}
			}
	        $field_values = json_encode($fields);
	     	$submit_time = strtotime($date);  
	        $user = 'Guest';
	        if (function_exists('is_user_logged_in') && is_user_logged_in()) {
	            $current_user = wp_get_current_user(); // WP_User
	            $user = $current_user->user_login;
	        }                   
	        $user = $user;
	        $ip = (isset($_SERVER['X_FORWARDED_FOR'])) ? $_SERVER['X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
	    }
		
		$_SESSION['authorize_token'] = md5(uniqid(rand(), true));
		$wpdb->insert( $wpdb->prefix . "cf7authorize_extension", array( 'id' => NULL, 
				'form_id' => $form_id, 
				'field_values' => $field_values, 
				'payment_details' => '', 
				'submit_time' => $submit_time,
				'token' => $_SESSION['authorize_token'],
				'user' => $user,
				'ip' => $ip), array( '%d', '%d', '%s', '%s', '%d', '%s', '%s' ) );	
	}
}