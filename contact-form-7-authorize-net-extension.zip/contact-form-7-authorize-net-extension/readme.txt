=== Contact Form 7 - Authorize.Net Extension ===

Contributors: zealopensource
Tags: accept credit card payment, Additional Settings, CF7 Authorize.Net, contact form, contact form 7, Contact Form 7 + PayPal, Contact Form 7 + Authorize.Net, contact form 7 sagepay, contact form 7 to paypal redirect, contact forms, Contact Forms 7, contacted, contactform7, contacts, donation on WordPress site, form, forms, integrate paypal button, integrate paypal with contact form 7, integrate Authorize.Net with contact form 7, integrate Authorize.Net, online payment, pay online, payment using credit card, payments on WordPress site, paypal button, Authorize.Net donation, Authorize.Net Payment Gateway, Authorize.Net plugin for wordpress, Paypal submit, redirect PayPal, redirect to paypal, Authorize.Net, Authorize.Net, Authorize.Net API, Authorize.Net checkout, Authorize.Net donation, Authorize.Net integration in Contact Form 7, Authorize.Net payment, Authorize.Net payment gateway, Authorize.Net plugin for wordpress, super Authorize.Net, wp Authorize.Net
Donate link: http://www.zealousweb.net/payment/
Requires at least: 3.0.1
Tested up to: 4.3.x
Stable tag: 1.0
License: GPLv3 or later License
CF7 requires at least: 3.0
CF7 tested up to: 4.3
Version: 1.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Contact Form 7 - Integrate Authorize.Net payment gateway for making your payments through Contact Form 7. 

== Description ==

Shortly after integrating a PayPal and Stripe payment gateway with Contact Form 7, ZealousWeb Technologies has now come up with a Authorize.Net payment gateway, which can also be successfully integrated with Contact Form 7.

Considering the fact that Contact Form 7 is a highly common and authentic WordPress Plugin, the new addon – “Contact Form 7 – Authorize.Net Extension” created by ZealousWeb Technologies, can prove to be extremely helpful for users when it comes to receiving payments.

There is no denying the fact that, users of WordPress websites confront a lot of payment related issues on a day-to-day basis, and in that case Contact Form 7 – Authorize.Net Extension can bring a great relief to them.

With the assistance of Contact Form 7 – Authorize.Net Extension, you can receive credit card or debit card payments directly from your customers, thus preventing them from landing up on a third party payment page.

Contact Form 7 – Authorize.Net Extension has the potential to receive payments safely from any Contact Form 7 form, which is hosted on any page or post for that matter. Once the contact form is submitted by the users, the payment checkout form is then displayed before them. The Authorize.Net payment checkout form is used for quick and secure transactions. This simply indicates that Contact Form 7 – Authorize.Net Extension can really help your websites to generate the revenue quickly.

What you need to understand about this plugin is it doesn’t rely on the action handler ‘on_set_ok’, which resides on the ‘Additional Settings’ tab of the CF7. Instead of that users can find a new tab ‘Authorize.Net’ wherein they can configure all the crucial fields needed to configure this plugin. For using this plugin, it is important for you to activate your Contact Form 7.

If you need any sort of technical assistance in terms of integrating Authorize.Net to your Contact Form 7, don’t hesitate to contact ZealousWeb Technologies, a leading web development company and the developers of this plugin.

= Contact Form 7 - Authorize.Net Extension Features =

*   This unique plugin gives you the authority to receive payments in 25 different currencies.
*   It gives you the potential to create multiple payment forms using Contact Form 7.
*   In addition to that, it also supports multiple forms on a single post or page.
*   When it comes to receiving values from input fields such as drop-down menu, textbox, hidden field, radio buttons, etc., Contact Form 7 – Authorize.Net Extension is really good at it.
*   The value for parameters like item description, amount and quantity is always accepted by it from the frontend.
*   When it comes to identifying whether the plugin is functioning properly or not, users can use Test API Mode.
*   The payment data associated to Contact Form 7 can be easily saved into the database.
*   Authorize.Net payment response details stored at admin side.
*   Its quite easy to export Contact Form 7 payment data to PDF and CSV.
*   All filters and search facility available at admin side.
*   With its assistance admin can easily edit or delete Contact Form 7 payment data.
*   Once a Authorize.Net payment is made successfully by the customers, the plugin sends individual emails to both the customer and the admin.
*   You can personalize email content for this plugin, Email(1) of Contact Form 7 is send to payee after successful transaction and Email(2) is send to admin after successful or unsuccessful transaction.
*   [authorize-net] tag added to email content gets replaced by Authorize.Net payment response in email.
*   It allows you to set payment success return url and custom message.


== Plugin Requirement ==

PHP version : 5.3 and latest
WordPress   : Wordpress 3.0 and latest

== Installation ==
1. There are two ways you can install this WordPress Plugin. Either Go to Plugins -> Add New and upload zip file of this plugin, or upload all files manually to your site’s server; click on the download button the page.
2. Now login to your WordPress site and activate the plugin. Then, select ‘edit’ option in ‘Contact Forms’.
3. You will find a new tab after "Additional Settings" tab. 
4. Fill in all the required fields to set up a Authorize.Net payment gateway.

== Screenshots ==
1. Screenshot 'screenshot-1.png' shows all the possible options available for this plugin.
2. Screenshot 'screenshot-2.png' shows front end view for second screen of this plugin.
3. Screenshot 'screenshot-3.png' shows admin sided view for this plugin with Authorize.Net response details.

== Changelog ==

= 1.0 =
* Initial Release