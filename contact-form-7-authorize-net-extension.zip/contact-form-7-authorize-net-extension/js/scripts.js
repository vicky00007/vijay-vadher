jQuery(document).ready(function(jQuery) {	
	var data = {
		'action': 'get_authorize_form_records',
		'form_id': jQuery('#contact_forms').val(),
		'form_name': jQuery('#contact_forms option:selected').text(),
		'rows':'5'
	};

	jQuery.post(admin_url, data, function(response) {			
		wpcf7_response(response);
	});
	
	jQuery('#contact_forms').change(function(){
		wpcf7_load_submissions();
	});	
	jQuery('.authorize-extension').on('click', '.header th',function(){		
		flag = (flag == '' || flag == 'desc') ? 'asc'	: 'desc';	
		field = jQuery(this).text().toLowerCase().trim();	
		field = field.replace(' ', '_'); 		
		if(field != "" && field != "delete"){				
			var data = wpcf7_data();		
			jQuery.post(admin_url, data, function(response) {
				wpcf7_response(response);						
			});
		} else if (field == "delete"){
			jQuery('input[id^="select_"]').attr('checked', jQuery('#selectall').prop('checked'));            	
		}
	});		
	jQuery('.authorize-extension').on('click', '.delete,#exportcsv,#exportpdf',function(){
		var list = [];		
		jQuery(".checklist:checked").each(function() {
			list.push(jQuery(this).val());
		});
		var action = jQuery(this).val();
		if(list != ""){
			var data = wpcf7_data();
			if(action == 'delete'){
				var c = confirm('Are you sure you want to delete the submission?');				
				if(c){						
					data.deletelist = list;				
					jQuery.post(admin_url, data, function(response) {
						wpcf7_response(response);						
					});
				}
			} else if(action == 'exportcsv'){				
				data.exportcsvlist = list;				
				jQuery.post(admin_url, data, function(response) {
					wpcf7_response(response);	
					var filelocation = jQuery('#downloadfile').val();	
					if(filelocation != undefined){
	                	window.location = filelocation;
	                }
				});
			}
			else if(action == 'exportpdf'){				
				data.exportpdflist = list;				
				jQuery.post(admin_url, data, function(response) {
					wpcf7_response(response);	
	                var filelocation = jQuery('#downloadfile').val();					
					if(filelocation != undefined){
	                	window.open(filelocation,'_blank');				
	                }					
				});
			}
		} else {
			alert('Please make the selection first');
		}
	});	
	jQuery('#search').click(function(){		
		searchtext = jQuery('#searchtext').val();		
		var data = wpcf7_data();
		jQuery.post(admin_url, data, function(response) {			
			wpcf7_response(response);
		});
	});			
});
function wpcf7_data()
{
	jQuery('.authorize-extension').css('opacity', '0.5');
	jQuery('#loading-image').css('display', 'inline-block');    
	var data = {
		'action': 'get_authorize_form_records',
		'method': 'post',
		'form_id': jQuery('#contact_forms').val(),
		'form_name': jQuery('#contact_forms option:selected').text(),
		'searchtext': searchtext,
		'field': field,
		'order': flag,
		'rows': rows
	};
	return data;
}
function wpcf7_response(response)
{
	jQuery('#display-records').html(response);
	jQuery('.header i').attr('class','fa fa-sort');	
	if(flag != "" && field != ""){
		if(flag == 'asc'){
			jQuery('#'+field+' i').attr('class','fa fa-sort-asc');
		} else if(flag == 'desc'){
			jQuery('#'+field+' i').attr('class','fa fa-sort-desc');
		} else {
			jQuery('#'+field+' i').attr('class','fa fa-sort');
		}
	}	
	jQuery('#rows').val(rows);
	jQuery('#searchtext').val(searchtext);
	jQuery('#loading-image').css('display', 'none');
    jQuery('.authorize-extension').css('opacity', '1');
	console.clear();
}
function wpcf7_load_submissions()
{
	rows = jQuery('#rows option:selected').val();		
	var data = wpcf7_data();	
	jQuery.post(admin_url, data, function(response) {
		wpcf7_response(response);
	});
}
function showEdit(editableObj) {
	jQuery(editableObj).addClass('editControl');
	jQuery(editableObj).attr('contenteditable','true');
} 
function saveToDatabase(editableObj,column,id) {		
	var editedVal = jQuery(editableObj).html();			
	var data = wpcf7_data();
	data.record_id = id;
	data.column = column;
	data.editedVal = editedVal;
	jQuery.post(admin_url, data, function(response) {
		wpcf7_response(response);
		jQuery(editableObj).removeClass('editControl');
	});
}
function wpcf7_status(value,id) {		
	var data = wpcf7_data();
	data.record_id = id;
	data.tostatus = value;
	jQuery.post(admin_url, data, function(response) {
		wpcf7_response(response);		
	});
}
function showpaymentdetails(record_id){
	jQuery('#authorize-payment-details'+record_id).dialog({
	 title : 'Payment Details',
     height: 400,
     width: 600,        
     show: {
         effect: "fade",
         duration: 1000
     },
     hide: {
         effect: "fade",
         duration: 500
     }     
	});
}
function changePage(pagenum, pages, range, showitems){	
	rows = jQuery('#rows option:selected').val();
	var data = wpcf7_data();
	data.page = pagenum;
	jQuery.post(admin_url, data, function(response) {
		wpcf7_response(response);
		jQuery('.pagination span').text('Page '+pagenum+' of '+pages);
		jQuery('.pagination a').switchClass('current','inactive');
		jQuery('.pagination #page'+pagenum).attr('class','current');
		
		if(pagenum > 2){			
			jQuery('<a id="page1" class="inactive first" onclick="changePage(1,'+pages+','+range+','+showitems+')"><<</a>').insertBefore('.pagination a:first');
		}
		if(pagenum < pages && showitems < pages){
			jQuery('<a class="inactive" onclick="changePage('+(pagenum + 1)+','+pages+','+range+','+showitems+')">></a>').insertBefore('.last');
		}		
		if(pagenum > 1 && showitems < pages){
			jQuery('<a class="inactive" onclick="changePage('+(pagenum - 1)+','+pages+','+range+','+showitems+')"><</a>').insertAfter('.first');			
		}	
		if(pagenum == pages){
			jQuery('#page'+pages).text(pages);
		}		
	});
}
