<?php
/**
 * Register the [authorize-net] shortcode for payment response in emails
 *
 * It will allow you to pass values in new tab 'authorize' like 
 * Test API/Secret key, Test Publishable key, Live API/Secret key, Live Publishable key, API mode, Currency, Item description, Item amount, Item quantity
 *
 * @access      public
 * @since       1.0 
 * @return      $content
*/
if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}
/** 
  * Returns layout with all submission listing to display at admin side menu
  */
function wpcf7_authorize_net_extension_payments_listing(){
	global $wpdb;
	$the_query = new WP_Query( 'post_type=wpcf7_contact_form' );
	echo "<div id='loading-image'></div>";	
	echo "<div class='authorize-extension'>";
	
	echo "<h2>Contact Form 7 - authorize Extension</h2>";
	$forms = $wpdb->get_results("SELECT ID,post_title FROM $wpdb->posts WHERE post_type = 'wpcf7_contact_form'");
	echo "<select id='contact_forms' name='contact_forms' class='floatleft'>";
	foreach($forms as $form){
		echo "<option value='".$form->ID."'>".$form->post_title."</option>";
	}
	echo "</select>";	
	echo "<div><button id='exportcsv' value='exportcsv' class='floatleft btn-primary'>Export To CSV</button></div>";
	//echo "<div><button id='exportpdf' value='exportpdf' class='floatleft btn-primary'>Export To PDF</button></div>";
	echo "<div class='floatright'><input type='text' name='searchtext' id='searchtext'/><button name='search' id='search' class='btn-primary'><i class='fa fa-search'></i></button></div>";
	echo "<div style='clear:both;'></div>";
	echo "<div id='display-records'></div>";	
	echo "</div>";
}

/**
  * Add Script to Admin head
  */
add_action( 'admin_head', 'wpcf7_authorize_extension_action_script' ); 
function wpcf7_authorize_extension_action_script() { ?>
	<script> 
		var admin_url = "<?php echo admin_url('admin-ajax.php'); ?>";
		var flag = '';	var searchtext = ''; var rows = '5';	var field = '';
	</script>
<?php }

/**
  * Add Script to Admin Footer
  */
add_action( 'admin_footer', 'wpcf7_authorize_extension_action_includes' ); 
function wpcf7_authorize_extension_action_includes() { 
	wp_enqueue_style( 'authorize_extension_style',plugins_url('/css/authorize-net-extension.css', __FILE__));
	wp_enqueue_script( 'authorize_extension_script',plugins_url('/js/scripts.js', __FILE__));
	wp_register_style( 'fontawesome', 'http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' );
	wp_enqueue_style( 'fontawesome'); 
	?>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<?php
}

/**
  * Add Pagination for submission listing at admin side
  */
function wpcf7_authorize_extension_pagination($pages = '', $range = 1, $current = 0)
{  	
	$showitems = ($range * 2)+1;  
	$showitems = ($pages < $showitems) ? $pages : $showitems;

	$paging = "<div class=\"pagination\"><select id='rows' onchange='wpcf7_load_submissions();'>";
	$paging .= "<option value='2'>2</option><option value='5' selected='selected'>5</option><option value='10'>10</option><option value='20'>20</option><option value='50'>50</option><option value='all'>All</option></select>";
	if($pages > 1){
		$paging .= "<span>Page 1 of ".$pages."</span>";		
		
		$starting = ($current > $showitems) ? $current : 1;
		for ($i=1; $i <= $showitems; $i++)	{
			if($pages == $current){
				$starting = $pages-($showitems - $i);
			}
			if(($pages-1) == $current){
				$starting = $pages-($showitems - $i);
			}
	    	$class = ($i == 1) ? 'current' : 'inactive';
	        $paging .= "<a id='page$starting' onclick='changePage($starting, $pages, $range, $showitems)' class='$class'>".$starting."</a>";           
	        $starting++;
		}
		if($pages > $showitems)	{
			$paging .= "<a id='page$pages' onclick='changePage($pages, $pages, $range, $showitems)' class='inactive last'>".">>"."</a>"; 
		}		
	}
	$paging .= "</div>\n";	
	return $paging;
}
/** 
  * Actual data manipulation goes here.. Ajax calls this function and gets response
  */
add_action( 'wp_ajax_get_authorize_form_records', 'wpcf7_authorize_extension_get_records' );

function wpcf7_authorize_extension_get_records() {
	global $wpdb; 
	$tablename = $wpdb->prefix . "cf7authorize_extension";
	$form_id = $_POST['form_id'];
	$form_name = $_POST['form_name'];
	$rows = $_POST['rows'];
	if(empty($rows)) { $rows = '2'; }  
	//For Sorting & Ordering
	$sortfield = ($_POST['field'] == 'delete') ? '' : $_POST['field'];
	$order = $_POST['order'];
	//For Searching
	$searchtext = $_POST['searchtext'];

	//For Deleting
	$deleteList = $_POST['deletelist'];
	if(isset($deleteList) && !empty($deleteList)){		
		$deleteList = implode(',' , $deleteList);
		$wpdb->query("DELETE FROM ".$tablename." WHERE id IN (".$deleteList.")");
	}	
	//For Inline Editing
	$record_id = $_POST['record_id'];
	$column = $_POST['column'];
	$editedVal = $_POST['editedVal'];
	if(isset($editedVal) && !empty($editedVal) && !empty($column)){
		$query = "SELECT field_values FROM $tablename WHERE id = ".$record_id;
		$oldvalue = $wpdb->get_var($query);
		$oldvalue = json_decode($oldvalue, true);
		$oldvalue[$column] = $editedVal;		
		$newvalue = json_encode($oldvalue);
		$wpdb->query("UPDATE ".$tablename." SET field_values = '".$newvalue."' WHERE id=".$record_id);
	}	
	//For changing status
	$tostatus = $_POST['tostatus'];
	if($tostatus == '0' || $tostatus == '1'){		
		$tostatus = ($tostatus == '0') ? 1 : 0;
		$wpdb->query("UPDATE ".$tablename." SET status = ".$tostatus." WHERE id=".$record_id);
	}
	//For export to CSV
	$exportCSVList = $_POST['exportcsvlist'];
	if(isset($exportCSVList) && !empty($exportCSVList)){
		$file = wpcf7_authorize_extension_exportToCSV($exportCSVList, $form_name);		
		$filename = plugins_url('/exports/csv/'.$file, __FILE__);
		$html = "<input type='hidden' id='downloadfile' value='$filename' name='downloadfile'>";
	}

	//For export to PDF
	/*$exportPDFList = $_POST['exportpdflist'];
	if(isset($exportPDFList) && !empty($exportPDFList)){
		$file = wpcf7_exportToPDF($exportPDFList, $form_name);		
		$filename = plugins_url('/exports/pdf/'.$file, __FILE__);
		$html = "<input type='hidden' id='downloadfile' value='$filename' name='downloadfile'>";
	}*/
	
	//Fetch Records
	$pagenum = (isset($_POST['page']) ? (($_POST['page'] - 1) * $rows) : 0) ;
	
	$query = "SELECT * FROM $tablename WHERE form_id ='".$form_id."'";
	if(isset($searchtext) && !empty($searchtext)){
		$query .= " AND (FROM_UNIXTIME(submit_time, '%d/%m/%Y %h:%i:%s') LIKE ':%".$searchtext."%' OR field_values LIKE '%".$searchtext."%')";
	}
	$query .= " ORDER BY id DESC";
	$totalrecords = $wpdb->get_results($query);
	if ($rows != 'all'){
		$query .= " LIMIT ".$pagenum.", ".$rows;
	}	
	
	//Make layout to display records
	$records = $wpdb->get_results($query);	
	if(count($records) > 0){
		$html .= "<div class='content1'><table cellspacing='0'><thead class='header'><th id='checklist'><input type='checkbox' name='selectall' id='selectall'><br><button class='delete' value='delete'>Delete</button></th>";
		$html .= "<th id='status'>Status</th><th id='submit_time'>Submit Time <i class=''></th>";

		$fields = json_decode($records[0]->field_values);	
		
		foreach($fields as $key=>$field){
			$html .= "<th id='$key'>".$key." <i class=''></th>";
		}
		$html .= "<th id='submitted_by'>Submitted By <i class=''></i></th><th id='submitted_from'>Submitted From <i class=''></th><th>&nbsp;</th></thead>";
		foreach($records as $key=>$record){ 					
			$record->field_values = json_decode($record->field_values);	
		}
		if(isset($sortfield) && !empty($sortfield)){	
			foreach($totalrecords as $key=>$record){ 					
				$record->field_values = json_decode($record->field_values);	
			}				
	 		foreach($totalrecords as $key=>$record){ 								
				$record->field_values->submit_time = $record->submit_time;
				$record->field_values->submitted_by = $record->user;
				$record->field_values->submitted_from = $record->ip;
			}	  	
			usort($totalrecords, function($arr1, $arr2) use ($sortfield) {				
				if(is_numeric($arr1->field_values->$sortfield))				{
		    		return ($arr1->field_values->$sortfield > $arr2->field_values->$sortfield) ? 1 : -1;
		    	} else 	{
		    		return strcmp($arr1->field_values->$sortfield, $arr2->field_values->$sortfield);
		    	}			     
			});		
			if($order == 'desc'){
				$records = array_reverse($totalrecords);
			} else {
				$records = $totalrecords;
			}
			foreach($records as $record){			
				unset($record->field_values->submit_time);
				unset($record->field_values->submitted_by);
				unset($record->field_values->submitted_from);
			}
			$records = array_slice($records, $pagenum, $rows);			
	  	}
	   	$count = 1;
		foreach($records as $record){
			$oddeven = ($count % 2);
			$html .= "<tr class='row".$oddeven."'>";
			$fields = $record->field_values;
			$payment_details = json_decode($record->payment_details, true);
			if(is_array($payment_details)){				
				$payments = '<table>';
				foreach($payment_details as $key=>$value){					
					$payments .= '<tr>';
					$payments .= '<td>'.ucwords(str_replace('_', ' ', $key)).'</td><td>:</td><td>'.$value.'</td>';
					$payments .= '</tr>';
				}
				$payments .= '</table>';
				echo "<div id='authorize-payment-details".$record->id."' class='authorize-payment-details'>".$payments."</div>";			
			}else{
				echo "<div id='authorize-payment-details".$record->id."' class='authorize-payment-details'><b>".$record->payment_details."</b></div>";
			}
			$html .="<td align='center'><input type='checkbox' name='checklist[]' class='checklist' value= '".$record->id."' id='select_".$record->id."'></td>";
			$status = ($record->status == '0') ? 'not-verified' : 'verified';
			$html .= "<td align='center'><span class='".$status."' id='status' onclick='wpcf7_status(".$record->status.",".$record->id.")'></span></td>";
			$html .= "<td>".date('d/m/Y h:i:s',$record->submit_time)."</td>";
			foreach($fields as $key=>$field){	
				$field = (is_array($field)) ? $field[0] : $field;		
				$html .= "<td onBlur='saveToDatabase(this,\"$key\",$record->id)' ondblclick='showEdit(this);'>".$field."</td>";
			}
			$html .= "<td>".$record->user."</td><td>".$record->ip."</td>";
			$html .= "<td><a href='#' onclick='showpaymentdetails(".$record->id.")'>View Authorize.Net Details</a></tr>";
			$count++;
		}
		
		$html .= "</table></div>";
		if($rows > 0)
			$pages = ceil(count($totalrecords) / $rows);
		if(count($totalrecords) > 2){			
			$current = (isset($_POST['page'])) ? $_POST['page'] : 0;
			$html .= "<div class='content2'>".wpcf7_authorize_extension_pagination($pages,1,$current)."</div>";
		}
		echo $html;
	} else {
		echo "<h1>No submissions found.<h1>";
	}
	wp_die();
}
function wpcf7_authorize_format_export_records($list,$filetype){
	global $wpdb; 
	$tablename = $wpdb->prefix . "cf7authorize_extension";
	$list = implode(',' , $list);
	$query = "SELECT * FROM $tablename WHERE id IN (".$list.") ORDER BY FIELD(id,".$list.");";
	$results = $wpdb->get_results($query);
	$break = ($filetype == 'csv') ? "\n" : "<br>";
	foreach($results as $key=>$record){
		$records[$key] = new StdClass;
		$records[$key]->Submit_Time = date('d/m/Y h:i:s',$record->submit_time); 
		$record->field_values = json_decode($record->field_values);	
		foreach($record->field_values as $fieldkey=>$fieldvalue){
			$fieldvalue = (is_array($fieldvalue)) ? $fieldvalue[0] : $fieldvalue;
			$records[$key]->$fieldkey = $fieldvalue;
		}
		$payment_details = json_decode($record->payment_details, true);	
		$payment_details_str = "";		
		if(is_array($payment_details)){
			foreach($payment_details as $fieldkey=>$fieldvalue){
				$payment_details_str .= $fieldkey.' - '.$fieldvalue.$break;
			}
		} else {
			$payment_details_str = $record->payment_details;
		}
		$records[$key]->Payment_Details = $payment_details_str;
		$records[$key]->Submitted_By = $record->user;
		$records[$key]->Submitted_From = $record->ip;		
	}
	return $records;
}
function wpcf7_authorize_extension_exportToCSV($exportcsvlist, $formname){	
	if(!empty($exportcsvlist)){		
		$records = wpcf7_authorize_format_export_records($exportcsvlist,'csv');
		$dir = dirname(__FILE__).'/exports/';
		if(!is_dir($dir)){
			mkdir($dir, 0777);		
		}
		if(!is_dir($dir.'csv/')){
			mkdir($dir.'csv/',0777);
		}
		$file = $formname.'_'.time(). '.csv';
		$filename = $dir.'csv/'.$file;
	    	
		$handle = fopen($filename, 'w+');
		foreach($records[0] as $key=>$value){
			$fields[]= str_replace('_',' ',$key);
		}
		
		fputcsv($handle, $fields);
		
		foreach ($records as $result) {
			$fieldvalues = array();
			foreach($result as  $key=>$value){			
				$fieldvalues[]= $value;
			}
			fputcsv($handle, $fieldvalues);
		}
		
		fclose($handle);
		ob_end_clean();
		if(file_exists($filename)){
			return $file;
		}
	}
}
/*function wpcf7_exportToPDF($exportpdflist, $formname){
	if(!empty($exportpdflist)){		
		$records = wpcf7_format_export_records($exportpdflist,'pdf');		
		$dir = dirname(__FILE__).'/exports/';
		if(!is_dir($dir)){
			mkdir($dir, 0777);		
		}
		if(!is_dir($dir.'pdf/')){
			mkdir($dir.'pdf/',0777);
		}
		$file = $formname.'_'.time().'.pdf';
		$html = '<html><head>'.$file.'</head><body><h1><u>'.$formname.'</u></h1>';
		$filename = $dir.'pdf/'.$file;
    	header("Content-Type: application/pdf");
		header("Content-Disposition: attachment; filename=".$filename.";");
		header("File:".$file);
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);		
		$pdf->SetFont('helvetica', '', 14);
		ob_start();	
		$pdf->AddPage();	
		foreach ($records as $record) {			
			$html .= '<table cellspacing="5" cellpadding="5">';		
			foreach($record as  $key=>$value){		
				$html .= '<tr><td width="25%">'.str_replace('_',' ',$key).'</td><td>'.$value.'</td></tr>';
			}
			$html .= '</table><hr><hr>';		
		}
		$html .= '</body></html>';
		$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
		$pdf->Output($filename, 'F');
		ob_end_clean();
		if(file_exists($filename)){
			return $file;
		}
	}
}*/
?>