<?php
/**
 * Plugin Name: Contact Form 7 - Authorize .NET Extension
 * Plugin URL: http://wordpress.org/plugins/contact-form-7-authorize-net-extension
 * Description:  This plugin will integrate Authorize .NET payment gateway for making your payments through Contact Form 7.
 * Version: 1.0
 * Author: ZealousWeb Technologies
 * Author URI: http://zealousweb.com
 * Developer: The Zealousweb Team
 * Developer E-Mail: info@opensource.zealousweb.com
 * Text Domain: contact-form-7-extension
 * Domain Path: /languages
 * 
 * Copyright: © 2009-2015 ZealousWeb Technologies.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

/**
 * 
 *
 * It will allow you to pass values in new tab 'Stripe' like 
 * Test API/Secret key, Test Publishable key, Live API/Secret key, Live Publishable key, API mode, Currency, Item description, Item amount, Item quantity
 *
 * @access      public
 * @since       1.0 
 * @return      $content
*/
if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}

require_once (dirname(__FILE__) . '/cf7-authorize-net-extension-update.php');
require_once (dirname(__FILE__) . '/cf7-authorize-net-extension.php');
//require_once (dirname(__FILE__) . '/lib/authorize-net-extension/init.php');

//require_once (dirname(__FILE__) . '/assets/TCPDF/tcpdf.php');

/**
  * Deactivate plugin on deactivation of Contact Form 7
  */ 
register_deactivation_hook(WP_PLUGIN_DIR.'/contact-form-7/wp-contact-form-7.php', 'authorize_net_contact_form_7_deactivate' );
function authorize_contact_form_7_deactivate()
{
	deactivate_plugins(WP_PLUGIN_DIR . '/contact-form-7-authorize-net-extension/contact-form-7-authorize-net-extension.php');
	wp_die( __( '<b>Warning</b> : Deactivating Contact Form 7 will deactivate "Contact Form 7 - Authorize .NET Extension" plugin automatically.', 'contact-form-7' ) );
}

/** 
  * Create table 'cf7stripe_extension' on plugin activation 
  **/
register_activation_hook (__FILE__, 'wpcf7_authorize_net_activation_check');
function wpcf7_authorize_net_activation_check()
{	
	//Check if Contact Form 7 is active and add table to database for stripe extension
    if ( !in_array( 'contact-form-7/wp-contact-form-7.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        wp_die( __( '<b>Warning</b> : Install/Activate Contact Form 7 to activate "Contact Form 7 - Authorize .NET Extension" plugin', 'contact-form-7' ) );
    } 
    else {
    	global $wpdb;
		$table_name = $wpdb->prefix . "cf7authorize_extension";
		if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
    		$sql = "CREATE TABLE $table_name (
    				`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
			      	`form_id` INT(11) NOT NULL,			      	
			      	`field_values` TEXT NOT NULL,
			      	`payment_details` TEXT NOT NULL,
			      	`submit_time` INT(11) NOT NULL,
			      	`user` VARCHAR(255) NOT NULL,
			      	`ip` VARCHAR(255) NOT NULL,
			      	`token` VARCHAR(255) NOT NULL,
			      	`status` TINYINT NOT NULL DEFAULT '0',
			      	`unsubscribe` TINYINT NOT NULL DEFAULT '0',
			      	PRIMARY KEY (`id`)
				) DEFAULT COLLATE=utf8_general_ci";

			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);			
		}
	}	
}


require_once (dirname(__FILE__) . '/cf7-authorize-net-extension-payment-form.php');
require_once (dirname(__FILE__) . '/cf7-authorize-net-extension-settings.php');
require_once (dirname(__FILE__) . '/cf7-authorize-net-extension-payments.php');

/**
  * Add Script to Admin Footer
  */
add_action( 'admin_footer', 'wpcf7_authorize_net_back_action_includes' ); 
function wpcf7_authorize_net_back_action_includes() { 
	wp_enqueue_style( 'authorize_net_extension_style',plugins_url('/css/authorize-net-extension.css', __FILE__));
	wp_register_style( 'fontawesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' );
	wp_enqueue_style( 'fontawesome'); 
	?>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script>
		jQuery(document).ready(function(){			
			if (jQuery(".authorize-net-settings input[name='use_authorize_net']").is(':checked')) {
				jQuery(".authorize-net-settings input[name='amount']").attr('required','required');
				jQuery(".authorize-net-settings input[name='liveapikey']").attr('required','required');
				jQuery(".authorize-net-settings input[name='livepublishkey']").attr('required','required');		
			}			
			if (jQuery(".authorize-net-settings input[name='apimode']").is(':checked')) {
				jQuery(".authorize-net-settings input[name='testapikey']").attr('required','required');
				jQuery(".authorize-net-settings input[name='testpublishkey']").attr('required','required');
			}			
			jQuery('#wpcf7-mail fieldset legend').append('<span class="mailtag code used">[authorize-net]</span>');
			jQuery(".authorize-net-settings input[name='use_authorize_net']").change(function() {
				if (jQuery(this).is(':checked')) {
					jQuery(".authorize-net-settings input[name='amount']").attr('required','required');
					jQuery(".authorize-net-settings input[name='liveapikey']").attr('required','required');
					jQuery(".authorize-net-settings input[name='livepublishkey']").attr('required','required');		
				} else {
					jQuery(".authorize-net-settings input[name='amount']").removeAttr('required');
					jQuery(".authorize-net-settings input[name='liveapikey']").removeAttr('required');
					jQuery(".authorize-net-settings input[name='livepublishkey']").removeAttr('required');
				}	
			});
			jQuery(".authorize-net-settings input[name='apimode']").change(function() {
				if (jQuery(this).is(':checked')) {
					jQuery(".authorize-net-settings input[name='testapikey']").attr('required','required');
					jQuery(".authorize-net-settings input[name='testpublishkey']").attr('required','required');
				} else {
					jQuery(".authorize-net-settings input[name='testapikey']").removeAttr('required');
					jQuery(".authorize-net-settings input[name='testpublishkey']").removeAttr('required');
				}
			});
		});
	</script>
<?php
}

add_action( 'wp_footer', 'wpcf7_authorize_net_front_action_includes' ); 
function wpcf7_authorize_net_front_action_includes() { 
	wp_enqueue_style( 'authorize_net_extension_style',plugins_url('/css/authorize-net-extension.css', __FILE__));
}

add_action( 'init', 'activate_authorize_net_update' );	
function activate_authorize_net_update()
{
	$plugin_current_version = '1.0';
	$plugin_remote_path = 'http://opensource.zealousweb.com/updates/cf7anet.php';	
	$plugin_slug = plugin_basename( __FILE__ );
	new WP_Authorize_AutoUpdate ( $plugin_current_version, $plugin_remote_path, $plugin_slug );	
}
?>