<?php
/* @access      public
 * @since       1.0 
 * @return      $content
*/
if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}
	//require_once(dirname(__FILE__).'/lib/authorize-extension/init.php');

/*===================== Contact Form 7 -  Authorize .NET Extension ====================*/
/*================== Authorize .NET Payment Form - Frontend Section ==================*/
/**
** A base module for  Authorize .NET express checkout form that allows to submit payment from Contact Form 7.
**/

//Add settings link to plugins page
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_action_links_authorize_net_extension' );

function add_action_links_authorize_net_extension ( $links ) {
     $settingslinks = array(
     '<a href="' . admin_url( 'admin.php?page=contact-form-7-authorize-net-extension' ) . '">Settings</a>',
     );
    return array_merge( $settingslinks, $links );
}

/** 
  * Add "PayPal Extension" Menu at admin side. Also "Settings" and "Payments" as submenus.
  */
add_action('admin_menu', 'authorize_net_extension_setup_menu');
function authorize_net_extension_setup_menu(){
    add_menu_page('authorize-net-extension', 'Authorize .NET Extension', 'manage_options','authorize-net-extension-payments', 'wpcf7_authorize_net_extension_payments_listing',plugins_url().'/contact-form-7-authorize-net-extension/images/authorize.net.png');
    
}

// Add authorize Tab after additional settings

add_filter( 'wpcf7_editor_panels', 'wpcf7_authorize_net_editor_panels' );
function wpcf7_authorize_net_editor_panels ( $panels ) {	
	$new_page = array(
		'Authorize.Net' => array(
			'title' => __( 'Authorize.Net', 'contact-form-7' ),
			'callback' => 'wpcf7_authorize_net_after_additional_settings'
		)
	);	
	$panels = array_merge($panels, $new_page);	
	return $panels;	
}

add_action('wpcf7_admin_after_additional_settings', 'wpcf7_authorize_net_after_additional_settings');

function wpcf7_authorize_net_after_additional_settings($cf7) 
{		
	$post_id = sanitize_text_field($_GET['post']);
	
	$use_authorize = get_post_meta($post_id, "_cf7authorize_use", true);
	$apimode = get_post_meta($post_id, "_cf7authorize_mode", true);
	$amount_field = get_post_meta($post_id, "_cf7authorize_amount", true);
	$description_field = get_post_meta($post_id, "_cf7authorize_description", true);
	$quantity_field = get_post_meta($post_id, "_cf7authorize_quantity", true);
	$auth_method_field = get_post_meta($post_id, "_cf7authorize_auth_method", true);

	$testapikey = get_post_meta($post_id, "_cf7authorize_testapikey", true);
	$testpublishkey = get_post_meta($post_id, "_cf7authorize_testpublishkey", true);
	$liveapikey = get_post_meta($post_id, "_cf7authorize_liveapikey", true);
	$livepublishkey = get_post_meta($post_id, "_cf7authorize_livepublishkey", true);
	$buttonlabel = get_post_meta($post_id, "_cf7authorize_buttonlabel", true);
	$returnURL = get_post_meta($post_id, "_cf7authorize_returnurl", true);
	$message = get_post_meta($post_id, "_cf7authorize_message", true);

	$currency_used = get_post_meta($post_id, "_cf7authorize_currency", true);
	
	if ($use_authorize == "1") { $checked = "CHECKED"; } else { $checked = ""; }
	if ($apimode == "1") { $testmode = "CHECKED"; } else { $testmode = ""; }
	$currency = array('AUD'=>'Australian Dollar','BRL'=>'Brazilian Real','CAD'=>'Canadian Dollar','CZK'=>'Czech Koruna','DKK'=>'Danish Krone','EUR'=>'Euro','HKD'=>'Hong Kong Dollar','HUF'=>'Hungarian Forint','ILS'=>'Israeli New Sheqel','JPY'=>'Japanese Yen','MYR'=>'Malaysian Ringgit','MXN'=>'Mexican Peso','NOK'=>'Norwegian Krone','NZD'=>'New Zealand Dollar','PHP'=>'Philippine Peso','PLN'=>'Polish Zloty','GBP'=>'Pound Sterling','RUB'=>'Russian Ruble','SGD'=>'Singapore Dollar', 'SEK'=>'Swedish Krona','CHF'=>'Swiss Franc','TWD'=>'Taiwan New Dollar','THB'=>'Thai Baht','TRY'=>'Turkish Lira','USD'=>'U.S. Dollar');
	$selected = '';
	$authorize_admin_settings = '<div class="authorize-settings"><table class="form-table"><tbody>';
	$authorize_admin_settings .= '<tr><td width="270"><label>Use Authorize.Net Payment Form</label></td><td><input type="checkbox" value="1" name="use_authorize" '.$checked.'></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Enable Test API Mode</label></td><td><input type="checkbox" value="1" name="apimode" '.$testmode.'></td></tr>';
	
	$authorize_admin_settings .= '<tr><td><label>Amount Field Name (required)</label></td><td><input type="text" value="'.$amount_field.'" name="amount"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Description Field Name (Optional)</label></td><td><input type="text" value="'.$description_field.'" name="description"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Quantity Field Name (Optional)</label></td><td><input type="text" value="'.$quantity_field.'" name="quantity"></td></tr>';

	$authorize_admin_settings .= '<tr><td><label>Select Currency</label></td><td><select name="currency">';
	foreach($currency as $key=>$value) { 
		
		if(empty($currency_used) && $key =="USD" ){
			$selected = "selected";
		} else if($key == $currency_used){
			$selected = "selected";
		} else {
			$selected ='';
		}
		$authorize_admin_settings .= '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
	}
	$authorize_admin_settings .= '</select></td></tr>';
	if($auth_method_field=='AIM'){$aim = 'checked';}else{$aim='';};
	if($auth_method_field=='SIM'){$sim = 'checked';}else{$sim='';};
	$authorize_admin_settings .= '<tr><td><label>Select Authorize.Net Method</label></td><td><input type="radio" name="auth_method" value="AIM" '.$aim.'>AIM </tr>';
	$authorize_admin_settings .= '<tr><td><label>API Login (required)</label></td><td><input type="text" class="large-text" value="'.$liveapikey.'" name="liveapikey"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Transaction Key (required)</label></td><td><input type="text" class="large-text" value="'.$livepublishkey.'" name="livepublishkey"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Form Buttom Label (Optional)</label></td><td><input type="text" class="large-text" value="'.$buttonlabel.'" name="buttonlabel"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Success Return URL (Optional)</label></td><td><input type="text" class="large-text" value="'.$returnURL.'" name="returnurl"></td></tr>';
	$authorize_admin_settings .= '<tr><td><label>Success Message (Optional)</label></td><td><input type="text" class="large-text" value="'.$message.'" name="message"></td></tr>';

	$authorize_admin_settings .= '<input type="hidden" name="post" value="'.$post_id.'"></tbody></table></div>';
	echo $authorize_admin_settings;		
}
	
//Save authorize settings of contact form 7 admin
add_action('wpcf7_save_contact_form', 'wpcf7_save_authorize_settings');
function wpcf7_save_authorize_settings($WPCF7_form) {
		
	$post_id = sanitize_text_field($_POST['post']);
	if (!empty($_POST['use_authorize'])) {
		$use_authorize = sanitize_text_field($_POST['use_authorize']);
		update_post_meta($post_id, "_cf7authorize_use", $use_authorize);
	} else {
		update_post_meta($post_id, "_cf7authorize_use", 0);
	}

	if (!empty($_POST['apimode'])) {
		$apimode = sanitize_text_field($_POST['apimode']);
		update_post_meta($post_id, "_cf7authorize_mode", $apimode);
	} else {
		update_post_meta($post_id, "_cf7authorize_mode", 0);
	}

	$amount_field = sanitize_text_field($_POST['amount']);
	update_post_meta($post_id, "_cf7authorize_amount", $amount_field);

	$description_field = sanitize_text_field($_POST['description']);
	update_post_meta($post_id, "_cf7authorize_description", $description_field);

	$quantity_field = sanitize_text_field($_POST['quantity']);
	update_post_meta($post_id, "_cf7authorize_quantity", $quantity_field);

	$auth_method_field = sanitize_text_field($_POST['auth_method']);
	update_post_meta($post_id, "_cf7authorize_auth_method", $auth_method_field);

	$liveapikey = sanitize_text_field($_POST['liveapikey']);
	update_post_meta($post_id, "_cf7authorize_liveapikey", $liveapikey);

	$livepublishkey = sanitize_text_field($_POST['livepublishkey']);
	update_post_meta($post_id, "_cf7authorize_livepublishkey", $livepublishkey);

	$currency = sanitize_text_field($_POST['currency']);
	update_post_meta($post_id, "_cf7authorize_currency", $currency);

	$buttonlabel = sanitize_text_field($_POST['buttonlabel']);
	update_post_meta($post_id, "_cf7authorize_buttonlabel", $buttonlabel);	

	$returnURL = sanitize_text_field($_POST['returnurl']);
	update_post_meta($post_id, "_cf7authorize_returnurl", $returnURL);		

	$message = sanitize_text_field($_POST['message']);
	update_post_meta($post_id, "_cf7authorize_message", $message);	
}

